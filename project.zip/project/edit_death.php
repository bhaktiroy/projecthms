<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $address=$_POST['address'];
    $gender=$_POST['gender'];
    $time=$_POST['time'];
	$date=$_POST['date'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `death_info` (`name`, `address`, `gender`, `time`, `date`, `visible`)
             VALUES('{$name}', '{$address}', '{$gender}', '{$time}', '{$date}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'death.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_death.html');
 ?>
