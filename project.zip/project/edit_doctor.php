<?php
require('session.php');
?>
<?php
require('emailvalid.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['dname'];
    $special=$_POST['speciality'];
    $contact=$_POST['contact'];
    $country=$_POST['country'];
	$gender=$_POST['gender'];
	$salary=$_POST['salary'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `ndoctor` (`doctor_name`, `specialist`, `contact`, `country`, `gender`, `salary`, `visible`)
             VALUES('{$name}', '{$special}', '{$contact}', '{$country}', '{$gender}', '{$salary}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'doctor.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
include('edit_dr_list.html');
?>

