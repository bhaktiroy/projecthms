<?php
require('session.php');
?>
<?php
require('doctors.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM ndoctor WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='doctors'>
    <tr>
    <th>Sl NO</th>
      <th>Doctor id</th>
      <th style='width:200px;'>Doctor name</th>
      <th>Specialist</th>
      <th>Contact</th>
      <th>Country</th>
	  <th>Gender</th>
	  <th>Salary</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['doctor_name'])."</td>";
      echo "<td>".$row['specialist']."</td>";
      echo "<td>".$row['contact']."</td>";
      echo "<td>".$row['country']."</td>";
	  echo "<td>".$row['gender']."</td>";
	  echo "<td>".$row['salary']."</td>";
      echo "<td>"."<a href = 'update_doctor.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
