<?php
require('session.php');
?>
<?php
require('operation.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM operation WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Operation id</th>
      <th style='width:200px;'>Patient name</th>
      <th>Doctor name</th>
      <th>Patient Problem</th>
      <th>Gain from operation</th>
	  <th>Date</th>
	  <th>Time</th>
	  <th>Gender</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['dname']."</td>";
      echo "<td>".$row['pprblm']."</td>";
      echo "<td>".$row['gain']."</td>";
	  echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['time']."</td>";
	  echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_operation.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'opdelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
