<?php
require('session.php');
?>
<?php
require('mobilevalid.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `staff_name`, `salary`, `phone`, `work`, `address`, `gender` FROM staff WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['staff_name'];
    $salary=$row['salary'];
	$phone=$row['phone'];
    $work=$row['work'];
    $address=$row['address'];
	$gender=$row['gender'];
	
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('edit_staff.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['sname'];
    $salary=$_POST['salary'];
	$phone=$_POST['phone'];
    $work=$_POST['work'];
    $address=$_POST['address'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE staff SET `staff_name`='{$name}', `salary`='{$salary}', `phone` = '{$phone}', `work` = '{$work}', `address` = '{$address}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'staff.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
