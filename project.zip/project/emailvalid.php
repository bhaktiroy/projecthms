<?php
require ('regggex.php');
include('dbconnect.php');
if (isset($_POST['submit'])) {
  $email =$_POST['contact'];
  if (email_validation($email)==1) {
    $sql="INSERT INTO regex(`contact`) VALUES('{$email}')";
    $result = mysqli_query($connection,$sql);
    if ($result) {
      echo "<script>alert('correct Email ID')</script>";
    }
  }else{
    echo "<script>alert('Incorrect Email ID')</script>";
  }
}
mysqli_close($connection);
//require('edit_dr_list.html');
?>