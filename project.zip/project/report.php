<DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>all reports</title>
<style>
{box-sizing: border-box;}

body {
  background-color:white;
  margin: 0;
  font-family: Arial;
}

.topnav {
  overflow: hidden;
  background-color:#87CEEB;
 
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
}

.topnav a:hover {
  background-color: #cce699;
  color: black;
}

.topnav a.active {
  background-color: #87CEEB;
  color:black;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #87CEEB;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

.media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }



</style>

<style>
/*time*/
#a1{
  background-color:	white;
  width: 200px;
  margin:auto;
  padding: 10px 10px 10px 10px;
  font-weight: bold;
  text-align: center;
  font-size: 50px;
  border-radius: 10px;
  float:right;
  
}
#serial{
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 70%;
	margin-left:150px;
	
}

#serial td, #serial th {
    border:1px solid #ddd;
    padding: 8px;
}

#serial tr:nth-child(even){background-color:  #ffffff;}
#serial tr:nth-child(odd){background-color: #f2f2f2;}
#serial tr:hover {background-color:  #fffafa;}

#serial th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align:left;
    background-color:#cce699;
    color: black;
}

a {
    text-decoration: none;
    display: inline-block;
    padding: 8px 16px;
	float:right;
}

a:hover {
    background-color: #ddd;
    color: black;
}

.previous {
    background-color:#87CEEB;
    color: black;
	float:left;
}

.next {
    background-color:  #87CEEB;
    color: black;
}
/*submt*/
.vokti{
  background-color:	white;
  padding: 10px 10px 10px 10px;
  font-weight: bold;
  text-align: center;
  font-size: 50px;
  border-radius: 10px;
}	
input{	
  background-color:	white;
  padding: 10px 10px 10px 10px;
  font-weight: bold;
  text-align: center;
  border-radius: 10px;
}
h3{	
  font-weight: bold;
  text-align: center;
}
</style>

</head>
<body>

<div class="topnav">
  <a class="active" href="#home"><b>All Reports</b></a>
  
  <div class="search-container">
    
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>
 <div id="a1"></div> <br/>
<br/>
<div class="vokti" style="border:none;">
<h3>All Reports Are Here!!</h3>
  <form action="" method="POST">
    <input type="submit" name="submit1" value="Doctor depend on salary>50000">
    <input type="submit" name="submit2" value="Appoint fee>500 ">
    <input type="submit" name="submit3" value="Nurse depend on salary>10000 ">
    <input type="submit" name="submit4" value="Staff depend on salary>80000 ">
    <input type="submit" name="submit5" value="Total earn from appointment ">
    <input type="submit" name="submit6" value="Total Earn from Admit Fee ">
	<input type="submit" name="submit7" value="Time based serial patient ">
  </form>
</div>

<?php
require('dbconnect.php');
if (isset($_POST['submit1'])) {
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM ndoctor WHERE `visible` = 1 AND `salary` >50000";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial' border=2>
    <tr>
      <th>Sl. No.</th>
      <th>Doctor name</th>
      <th>contact</th>
      <th>gender</th>
      <th>salary</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".ucwords($row['doctor_name'])."</td>";
      echo "<td>".$row['contact']."</td>";
      echo "<td>".$row['gender']."</td>";
      echo "<td>".$row['salary']."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}

if (isset($_POST['submit2'])) {
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM appoint WHERE `visible` = 1 AND `fee` >500";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial' border=2>
    <tr>
      <th>Sl. No.</th>
      <th>Patient Name</th>
      <th>Doctor name</th>
	  <th>Time</th>
	  <th>Date</th>
	  <th>Fee</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['dname']."</td>";
	  echo "<td>".$row['time']."</td>";
	  echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['fee']."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}

if (isset($_POST['submit3'])) {
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM nurse WHERE `visible` = 1 AND `salary` >10000";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial' border=2>
    <tr>
      <th>Sl. No.</th>
      <th>Name</th>
      <th>salary</th>
      <th>phone</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".ucwords($row['nurse_name'])."</td>";
      echo "<td>".$row['salary']."</td>";
      echo "<td>".$row['phone']."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}

if (isset($_POST['submit4'])) {
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM staff WHERE `visible` = 1 AND `salary` >8000";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial' border=2>
    <tr>
      <th>Sl. No.</th>
      <th>Staff Name</th>
      <th>salary</th>
      <th>gender</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".ucwords($row['staff_name'])."</td>";
      echo "<td>".$row['salary']."</td>";
      echo "<td>".$row['gender']."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}

if (isset($_POST['submit5'])) {
  if (!mysqli_connect_errno()) {
	$query = "SELECT * FROM appoint";
	$query_run = mysqli_query($connection,$query);

	$total= 0;
	while ($num = mysqli_fetch_array ($query_run, MYSQLI_BOTH)) {
    $total += $num['fee'];
   }
	echo "<b><script>alert('result : $total.tk');</script></b>";
   }else{
	echo "Database Connection Failed";
  }
  mysqli_close($connection);
}
if (isset($_POST['submit6'])) {
  if (!mysqli_connect_errno()) {
	$query = "SELECT * FROM release_info";
	$query_run = mysqli_query($connection,$query);

	$total = 0;
	while ($num = mysqli_fetch_array ($query_run, MYSQLI_BOTH)) {
    $total += $num['full_fee'];
   }
	echo "<b><script>alert('result : $total .tk');</script></b>";
   }else{
	echo "Database Connection Failed";
  }
  mysqli_close($connection);
}

if (isset($_POST['submit7'])) {
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM serial WHERE `visible` = 1 AND `date` =2018-03-03";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial' border=2>
    <tr>
      <th>Sl. No.</th>
      <th>Patient Name</th>
      <th>Doctor Name</th>
      <th>date</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['dname']."</td>";
      echo "<td>".$row['date']."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>