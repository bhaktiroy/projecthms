<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $dname=$_POST['dname'];
    $pprblm=$_POST['pprblm'];
    $gain=$_POST['gain'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `operation`(`pname`, `dname`, `pprblm`, `gain`, `date`, `time`, `gender`, `visible`)
             VALUES('{$pname}', '{$dname}', '{$pprblm}', '{$gain}', '{$date}', '{$time}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'operation.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_operation.html');
 ?>
