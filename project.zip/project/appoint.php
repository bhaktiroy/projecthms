<?php
require('session.php');
?>
<?php
require('appointments.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM appoint WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='appointments'>
    <tr>
    <th>Sl NO</th>
    <th>Patient id</th>
      <th style='width:200px;'>Patient name</th>
      <th style='width:200px;'>Appointed Doctor's name</th>
      <th>Time</th>
      <th>Date</th>
	  <th>Fee</th>
      <th>Patient problem</th>
      <th>Patient address</th>
      <th>Gender</th>
      
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td>".$row['pname']."</td>";
      echo "<td>".$row['dname']."</td>";
      echo "<td>".$row['time']."</td>";
      echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['fee']."</td>";
      echo "<td>".$row['pprblm']."</td>";
      echo "<td>".$row['paddress']."</td>";
      echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_appoint.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'appdelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
