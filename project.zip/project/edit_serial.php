<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $dname=$_POST['dname'];
    $time=$_POST['time'];
    $date=$_POST['date'];
	$paddress=$_POST['paddress'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `serial` (`pname`, `dname`, `time`, `date`, `paddress`, `gender`, `visible`)
             VALUES('{$pname}', '{$dname}', '{$time}', '{$date}', '{$paddress}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'serial.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_serial.html');
 ?>
