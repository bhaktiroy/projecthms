<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $bedno=$_POST['bedno'];
    $pprblm=$_POST['pprblm'];
    $position=$_POST['position'];
	$date=$_POST['date'];
	$full_fee=$_POST['full_fee'];
	$due_fee=$_POST['due_fee'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `release_info`(`pname`, `bedno`, `pprblm`, `position`, `date`, `full_fee`, `due_fee`, `gender`, `visible`)
             VALUES('{$pname}', '{$bedno}', '{$pprblm}', '{$position}', '{$date}', '{$full_fee}', '{$due_fee}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'release.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_release.html');
 ?>
