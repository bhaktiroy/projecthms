<?php
require('session.php');
?>
<?php
require('mobilevalid.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['nname'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $salary=$_POST['salary'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `nurse` (`nurse_name`, `address`, `phone`, `salary`, `visible`)
             VALUES('{$name}', '{$address}', '{$phone}', '{$salary}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'nurses.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('edit_nurse.html');
 ?>
