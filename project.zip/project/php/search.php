<?php
mysql_connect("localhost", "root", "password") or die("couldn't connect");
mysql_select_db("bhakti_hms") or die("couldn't connect");
if(isset($_POST['search'])){
	$searchq=$_POST['search'];
	$searchq=preg_replace("#[^0-9a-z]#i","",$searchq);
	$query=mysql_query("SELECT * FROM ndoctor WHERE dname '%$search%'") or die("couldn't find"); 
	$count=mysql_num_rows($query);
	if (count==o){
		echo "there is no search result";
	}else{ 
	while($row=mysql_fetch_array($query)){
    $name=$row['doctor_name'];
    $special=$row['specialist'];
    $contact=$row['contact'];
    $country=$row['country'];
	$gender=$row['gender'];
	$salary=$row['salary'];	
  }
}
  $output.= $name.$special.$contact.$country.$gender.$salary."<br>";
}	

?>