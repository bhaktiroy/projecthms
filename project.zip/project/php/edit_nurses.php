<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['nname'];
    $salary=$_POST['salary'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `nurse` (`nurse_name`, `salary`, `phone`, `address`, `visible`)
             VALUES('{$name}', '{$address}', '{$phone}', '{$salary}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'nurses.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('new_nuse.html');
 ?>
