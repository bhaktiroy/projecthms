<?php
require('session.php');
?>
<?php
if(isset($_POST["submit"])){
 if(!empty($_POST['user']) && !empty($_POST['password'])){
 $user = $_POST['user'];
 $password = $_POST['password'];
 $conn = new mysqli('localhost', 'root', '') or die (mysqli_error()); // DB Connection
 $db = mysqli_select_db($conn, 'bhakti_hms') or die("DB Error"); // Select DB from database
 //Selecting Database
 $query = mysqli_query($conn, "SELECT * FROM login_user WHERE user='".$user."'");
 $numrows = mysqli_num_rows($query);
 if($numrows == 0)
 {
 //Insert to Mysqli 
 $sql = "INSERT INTO login_user(user,password) VALUES('$user','$password')";
 $result = mysqli_query($conn, $sql);
 //Result Message
 if($result){
 echo "<b><script>alert('SUCCESS : Your Account Created Successfully');</script></b>";
 }
 else
 {
 echo "Failure!";
 }
 }
 else
 {
 echo "<b><script>alert('your account already exit, so try again');</script></b>";
 }
 require('index.html');
 ?>
