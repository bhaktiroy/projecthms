<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `name`, `fname`, `mname`, `address`, `time`, `date`, `gender` FROM birth_info WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['name'];
    $fname=$row['fname'];
    $mname=$row['mname'];
    $address=$row['address'];
	$time=$row['time'];
	$date=$row['date'];
	$gender=$row['gender'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_birth.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $fname=$_POST['fname'];
    $mname=$_POST['mname'];
    $address=$_POST['address'];
	$time=$_POST['time'];
	$date=$_POST['date'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE birth_info SET `name`='{$name}', `fname`='{$fname}', `mname` = '{$mname}', `address` = '{$address}', `time` = '{$time}', `date` = '{$date}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'birth.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
