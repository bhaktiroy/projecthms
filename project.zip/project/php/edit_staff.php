<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['sname'];
    $salary=$_POST['salary'];
    $phone=$_POST['phone'];
    $work=$_POST['work'];
	$address=$_POST['address'];
	$gender=$_POST['gender'];
	
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `staff` (`staff_name`, `salary`, `phone`, `work`, `address`, `gender`, `visible`)
             VALUES('{$name}', '{$salary}', '{$phone}', '{$work}', '{$address}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'staff.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('new_staff.html');
 ?>
