<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `pname`, `bedno`, `pprblm`, `position`, `date`, `full_fee`, `due_fee`, `gender` FROM release_info WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $pname=$row['pname'];
    $bedno=$row['bedno'];
    $pprblm=$row['pprblm'];
    $position=$row['position'];
	$date=$row['date'];
	$full_fee=$row['full_fee'];
	$due_fee=$row['due_fee'];
	$gender=$row['gender'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_release.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $bedno=$_POST['bedno'];
    $pprblm=$_POST['pprblm'];
    $position=$_POST['position'];
	$date=$_POST['date'];
	$full_fee=$_POST['full_fee'];
	$due_fee=$_POST['due_fee'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE release_info SET `pname`='{$pname}', `bedno`='{$bedno}', `pprblm` = '{$pprblm}', `position` = '{$position}', `date` = '{$date}', `full_fee` = '{$full_fee}', `due_fee` = '{$due_fee}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'release.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
