<?php
require('session.php');
?>
<?php
require('slot.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM serial WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='serial'>
    <tr>
      <th>Sl NO</th>
	  <th>serial id</th>
      <th style='width:200px;'>Patient name</th>
      <th>Doctor name</th>
      <th>time</th>
      <th>date</th>
	  <th>paddress</th>
	  <th>gender</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['dname']."</td>";
      echo "<td>".$row['time']."</td>";
      echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['paddress']."</td>";
	  echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_serial.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'sedelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
