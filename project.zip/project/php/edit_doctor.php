<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['dname'];
    $special=$_POST['speciality'];
    $contact=$_POST['contact'];
    $country=$_POST['country'];
	$gender=$_POST['gender'];
	$salary=$_POST['salary'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `ndoctor` (`doctor_name`, `specialist`, `contact`, `country`, `gender`, `salary`, `visible`)
             VALUES('{$name}', '{$special}', '{$contact}', '{$country}', '{$gender}', '{$salary}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'doctor.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
include('datavalid.php');
 ?>
 <?php
//include('datavalid.php');
?>
 <?php
require('session.php');
?>
<!DOCTYPE html>
<html>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>New Doctor</title>

<head>


<style>
body {
  background-color:white;}

.block {
    display: block;
    width: 100%;
    border: none;
    background-color:#87CEEB;
    color: black;
    padding: 14px 28px;
    font-size:18px;
    cursor: pointer;
    text-align: center;
}

.block:hover {
    background-color:#cce699;
    color: black;
}
</style>

<style>
 {
    box-sizing: border-box;
}

input[type=text], select, textarea{
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    resize: vertical;
}

label {
    padding: 10px 10px 10px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #87CEEB;
    color: black;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left:365px;
	margin-top:10px;
}
input[type=submit]:focus{

}
input[type=submit]:hover {
    background-color:#cce699;
}

.container {
    border-radius: 5px;
    background-color:#f5f5f5;
    padding: 10px;
	margin-left:400px;
	margin-top:40px;
	width:500px;
}

.a2 {
    float: left;
    width: 30%;
    margin-top: 6px;
}

.a3 {
    float: left;
    width: 60%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: tx1le;
    clear: both;
}


</style>

</head>
<body>
<button class="block">Add New Doctor</button>

<div class="container">
  <form  action="#" method="post">
	<div class="row">
      <div class="a2">
        <label for="name">Doctor Name</label>
      </div>
      <div class="a3">
        <input type="text" id="name" name="dname" placeholder="Type name..">
      </div>
    </div>
    <div class="row">
      <div class="a2">
        <label for="name">Specialist of</label>
      </div>
      <div class="a3">
        <input type="text" id="name" name="speciality" placeholder="Type speciality">
      </div>
    </div>
    <div class="row">
      <div class="a2">
        <label for="name">Contact</label>
      </div>
      <div class="a3">
        <input type="text" id="name" name="contact" placeholder="email/phone no...">
      </div>
	</div>
	<div class="row">
      <div class="a2">
        <label for="contact">Country</label>
      </div>
      <div class="a3">
        <select id="country" name="country">
          <option value="Bangladesh">Bangladesh</option>
          <option value="India">India</option>
          <option value="usa">USA</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="a2">
        <label for="name">Gender</label>
      </div>
      <div class="a3">
        <input type="text" id="name" name="gender" value="" placeholder="Type gender...">
      </div>
	</div>
	<div class="row">
      <div class="a2">
        <label for="name">Salary</label>
      </div>
      <div class="a3">
        <input type="text" id="name" name="salary" value="" placeholder="Type salary...">
      </div>
	</div>
    <div class="row">
      <input type="submit" name="submit" value="Submit">
    </div>
  </form>
</div>

</body>
</html>
