<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `bgroup`, `donrname`, `pname`, `date` FROM blood WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $bgroup=$row['bgroup'];
    $donrname=$row['donrname'];
    $pname=$row['pname'];
    $date=$row['date'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_blood.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $bgroup=$_POST['bgroup'];
    $donrname=$_POST['donrname'];
    $pname=$_POST['pname'];
    $date=$_POST['date'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE blood SET `bgroup`='{$bgroup}', `donrname`='{$donrname}', `pname` = '{$pname}', `date` = '{$date}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'blood.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
