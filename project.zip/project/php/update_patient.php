<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `patient_name`, `address`, `phone`, `gender` FROM npatient WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['patient_name'];
    $address=$row['address'];
    $phone=$row['phone'];
    $gender=$row['gender'];

  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('edit_patient.html');
//Update the data and Save it into the MySQL database;
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['pname'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE npatient SET `patient_name`='{$name}', `address`='{$address}', `phone` = '{$phone}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'patient.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
