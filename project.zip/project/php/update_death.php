<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `name`, `address`, `gender`, `time`, `date` FROM death_info WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['name'];
    $address=$row['address'];
    $gender=$row['gender'];
    $time=$row['time'];
	$date=$row['date'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_death.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $address=$_POST['address'];
    $gender=$_POST['gender'];
    $time=$_POST['time'];
	$date=$_POST['date'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE death_info SET `name` = '{$name}', `address` = '{$address}', `gender` = '{$gender}', `time` = '{$time}', `date` = '{$date}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'death.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
