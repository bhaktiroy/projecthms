<?php
require('session.php');
?>
<?php
$connection = mysqli_connect('localhost','root', '', 'bhakti_hms');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $visibility = 0;
  $update_query = "UPDATE salary SET `visible`= '{$visibility}' WHERE `id`='{$id}' ";
  if (mysqli_query($connection,$update_query)) {
    echo "<script>window.location.href = 'salary.php'</script>";
  }else{
    echo "ERROR : failed to Delete data"."<br>";
  }
}
mysqli_close($connection);
?>
