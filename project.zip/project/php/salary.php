<?php
require('session.php');
?>
<?php
require('salary.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM salary WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Salary id</th>
	  <th>Salary Amount</th>
      <th style='width:200px;'>Name</th>
      <th>Work Performance</th>
      <th>Position</th>
	  <th>Gender</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
	  echo "<td>".$row['slamount']."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['name'])."</td>";
      echo "<td>".$row['work']."</td>";
      echo "<td>".$row['position']."</td>";
	  echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_salary.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'saldelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
