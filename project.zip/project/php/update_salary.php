<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `slamount`, `name`, `work`, `position`, `gender` FROM salary WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $slamount=$row['slamount'];
    $name=$row['name'];
    $work=$row['work'];
    $position=$row['position'];
	$gender=$row['gender'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_salary.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $slamount=$_POST['slamount'];
    $name=$_POST['name'];
    $work=$_POST['work'];
    $position=$_POST['position'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE salary SET `slamount`='{$slamount}', `name`='{$name}', `work` = '{$work}', `position` = '{$position}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'salary.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
