<?php
//Email validation
function email_validation($email){
  $regex = '/([a-z0-9])+\@+([a-z])+(\.)+([a-z]{2,6})/';
  if (preg_match($regex,$email)) {
    return 1;
  }else {
    return 0;
  }
}
//Bangladesh mobile number validation
function bangladesh_mobile_validation($mobile){
  $regex = '/01[^1-4]\d{8}/';
  if (preg_match($regex,$mobile)) {
    return 1;
  }else {
    return 0;
  }
}
//Stop SQL Injection into the Database by disallowing all "Special Characters"
function stop_sql_injection_validation($sql_injection){
  $regex = '/^([1-zA-Z0-1@.\s]{1,255})$/';
  if (preg_match($regex,$sql_injection)) {
    return 1;
  }else {
    return 0;
  }
}
?>