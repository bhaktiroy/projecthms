<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `doctor_name`, `specialist`, `contact`, `country`, `gender`, `salary` FROM ndoctor WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['doctor_name'];
    $special=$row['specialist'];
    $contact=$row['contact'];
    $country=$row['country'];
	$gender=$row['gender'];
	$salary=$row['salary'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('edit_dr_list.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['dname'];
    $special=$_POST['speciality'];
    $contact=$_POST['contact'];
    $country=$_POST['country'];
	$gender=$_POST['gender'];
	$salary=$_POST['salary'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE ndoctor SET `doctor_name`='{$name}', `specialist`='{$special}', `contact` = '{$contact}', `country` = '{$country}', `gender` = '{$gender}', `salary` = '{$salary}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'doctor.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
