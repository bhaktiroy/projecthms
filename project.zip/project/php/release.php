<?php
require('session.php');
?>
<?php
require('release.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM release_info WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Admit id</th>
      <th style='width:200px;'>Patient name</th>
      <th>Bed no:</th>
      <th>Patient Problem</th>
      <th>Position</th>
	  <th>Date</th>
	  <th>Full fee payment</th>
	  <th>Due fee</th>
	  <th>Gender</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['bedno']."</td>";
      echo "<td>".$row['pprblm']."</td>";
      echo "<td>".$row['position']."</td>";
	  echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['full_fee']."</td>";
	  echo "<td>".$row['due_fee']."</td>";
	  echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_release.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'reldelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
