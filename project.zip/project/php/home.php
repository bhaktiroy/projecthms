<?php
require('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link rel="stylesheet" href="css/home.css">
</head>
<body>
<button class="blockbutton">Hospital Management System</button>
 <div class="scrollmenu">
  <a href="#home">Home</a>
  <a href="edit_doctor.php">Add Doctor</a>
  <a href="edit_patient.php">Add Patient</a>
  <a href="edit_appoint.php">Add Appointment</a>
  <a href="edit_nurses.php">Add Nurse</a>
  <a href="edit_staff.php">Add Staff</a>
  <a href="edit_serial.php">Add serial time</a>  
  <a href="edit_blood.php">Add Blood document</a>
  <a href="edit_salary.php">Salary document</a>
  <a href="edit_operation.php">Operation Info</a>
  <a href="edit_admit.php">Admit Info</a>
  <a href="edit_release.php">Release Info</a>
  <a href="edit_death.php">Death Report</a>
  <a href="edit_birth.php">Birth Report</a>
  <a href="logout.php">log out</a>
</div>
<div id="mySidenav" class="sidenav">
  <a href="doctor.php" id="a1">Doctors</a>
  <a href="patient.php" id="a2">Patients</a>
  <a href="appoint.php" id="a3">Appointments</a>
  <a href="report.php" id="a4">Reports</a>
  <a href="staff.php" id="a5">Staffs</a>
  <a href="nurses.php" id="a6">Nurses</a>
  <a href="serial.php" id="a7">Serial Times</a>
  <a href="profile.html" id="a8">Admin Profile</a>
</div>
<div class="container">
  <img src="img/back.jpg" alt="img" style="width:100%;">
</div>





<script>
document.onmousedown=RightClickDisable;
function RightClickDisable(event){
if(event.button==2){
alert ("Sorry: Your Right Click has been disabled by the administrators");
return false;
}
}
</script>







</body>
</html>
