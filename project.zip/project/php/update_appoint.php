<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `pname`, `dname`, `time`, `date`, `fee`, `pprblm`, `paddress`, `gender` FROM appoint WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $pname=$row['pname'];
    $dname=$row['dname'];
    $time=$row['time'];
    $date=$row['date'];
	$fee=$row['fee'];
    $pprblm=$row['pprblm'];
    $paddress=$row['paddress'];
    $gender=$row['gender'];
	}
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('edit_appoint.html');
//Update the data 
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $dname=$_POST['dname'];
    $time=$_POST['time'];
    $date=$_POST['date'];
	$fee=$_POST['fee'];
    $pprblm=$_POST['pprblm'];
	$paddress=$_POST['paddress'];
    $gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE appoint SET `pname`='{$pname}', `dname`='{$dname}', `time` = '{$time}', `date` = '{$date}', `fee` = '{$fee}', `pprblm` = '{$pprblm}',  `paddress`='{$paddress}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'appoint.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
