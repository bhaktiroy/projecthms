<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `pname`, `bedno`, `pprblm`, `position`, `date` FROM admit_info WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $pname=$row['pname'];
    $bedno=$row['bedno'];
    $pprblm=$row['pprblm'];
    $position=$row['position'];
	$date=$row['date'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_admit.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $bedno=$_POST['bedno'];
    $pprblm=$_POST['pprblm'];
    $position=$_POST['position'];
	$date=$_POST['date'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE admit_info SET `pname`='{$pname}', `bedno`='{$bedno}', `pprblm` = '{$pprblm}', `position` = '{$position}', `date` = '{$date}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'admit.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
