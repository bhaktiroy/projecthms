<?php
require('session.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `pname`, `dname`, `pprblm`, `gain`, `date`, `time`, `gender` FROM operation WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $pname=$row['pname'];
    $dname=$row['dname'];
    $pprblm=$row['pprblm'];
    $gain=$row['gain'];
	$date=$row['date'];
	$time=$row['time'];
	$gender=$row['gender'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('add_operation.html');
//Update the data
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $dname=$_POST['dname'];
    $pprblm=$_POST['pprblm'];
    $gain=$_POST['gain'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE operation SET `pname`='{$pname}', `dname`='{$dname}', `pprblm` = '{$pprblm}', `gain` = '{$gain}', `date` = '{$date}', `time` = '{$time}', `gender` = '{$gender}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'operation.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
