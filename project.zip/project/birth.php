<?php
require('session.php');
?>
<?php
require('birth.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM birth_info WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Birth id</th>
      <th style='width:200px;'>Name</th>
      <th>Father's Name</th>
      <th>Mother's Name</th>
      <th>Address</th>
	  <th>Time</th>
	  <th>Date</th>
	  <th>Gender</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['name'])."</td>";
      echo "<td>".$row['fname']."</td>";
      echo "<td>".$row['mname']."</td>";
      echo "<td>".$row['address']."</td>";
	  echo "<td>".$row['time']."</td>";
	  echo "<td>".$row['date']."</td>";
	  echo "<td>".$row['gender']."</td>";
      echo "<td>"."<a href = 'update_birth.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'birdelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
