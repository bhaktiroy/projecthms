<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $bgroup=$_POST['bgroup'];
    $donrname=$_POST['donrname'];
    $pname=$_POST['pname'];
    $date=$_POST['date'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `blood` (`bgroup`, `donrname`, `pname`, `date`, `visible`)
             VALUES('{$bgroup}', '{$donrname}', '{$pname}', '{$date}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'blood.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_blood.html');
 ?>
