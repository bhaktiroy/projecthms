<?php
require('session.php');
?>
<DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admit</title>
<style>
{box-sizing: border-box;}

body {
  background-color:white;
  margin: 0;
  font-family: Arial;
}

.topnav {
  overflow: hidden;
  background-color:#87CEEB;
 
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
}

.topnav a:hover {
  background-color: #cce699;
  color: black;
}

.topnav a.active {
  background-color: #87CEEB;
  color:black;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #87CEEB;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

.media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }



</style>

<style>
/*time*/
#a1{
  background-color:	white;
  width: 200px;
  margin:auto;
  padding: 10px 10px 10px 10px;
  font-weight: bold;
  text-align: center;
  font-size: 50px;
  border-radius: 10px;
  float:right;
  
}
#voktu{
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 70%;
	margin-left:150px;
	
}

#voktu td, #voktu th {
    border:1px solid #ddd;
    padding: 8px;
}

#voktu tr:nth-child(even){background-color:  #ffffff;}
#voktu tr:nth-child(odd){background-color: #f2f2f2;}
#voktu tr:hover {background-color:  #fffafa;}

#voktu th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align:left;
    background-color:#cce699;
    color: black;
}

a {
    text-decoration: none;
    display: inline-block;
    padding: 8px 16px;
	float:right;
}

a:hover {
    background-color: #ddd;
    color: black;
}

.previous {
    background-color:#87CEEB;
    color: black;
	float:left;
}

.next {
    background-color:  #87CEEB;
    color: black;
}

</style>

</head>
<body onload="startTime()">

<div class="topnav">
  <a class="active" href="#home"><b>Admit Info</b></a>
  
  <div class="search-container">
    
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>
 <div id="a1"></div> <br/>
<br/>


<?php

include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM admit_info WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Admit id</th>
      <th style='width:200px;'>Patient name</th>
      <th>Bed no:</th>
      <th>Patient Problem</th>
      <th>Position</th>
	  <th>Date</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['pname'])."</td>";
      echo "<td>".$row['bedno']."</td>";
      echo "<td>".$row['pprblm']."</td>";
      echo "<td>".$row['position']."</td>";
	  echo "<td>".$row['date']."</td>";
      echo "<td>"."<a href = 'update_admit.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'admdelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>


<a href="home.html" class="previous">&laquo; Previous</a>
<a href="edit_admit.php" class="next">Next &raquo;</a>

<script>
function startTime() {
  var today = new Date();
  var hours = today.getHours();
  var minutes = today.getMinutes();
  var seconds = today.getSeconds();
  minutes = checkTime(minutes);
  seconds = checkTime(seconds);
  document.getElementById('a1').innerHTML = hours + ":" + minutes + ":" + seconds;
  var t = setTimeout(startTime, 100);
}
function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}
</script>

  </body>
</html>	
