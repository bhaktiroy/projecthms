<?php
require('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link rel="stylesheet" href="css/home.css">
<style>
body  {
    background-image: url("img/hasina.jpg");
    background-color: #cccccc;
}
#hh h1{
	font-size: 60px;
	font-style: italic;
	color: black;
	margin-top:18%;
	text-align:center;
	text-shadow: 2px 2px white;
}
</style>
</head>
<body>
<button class="blockbutton">Hospital Management System</button>
 <div class="scrollmenu">
  <a href="#home">Home</a>
  <a href="edit_doctor.php">Add Doctor</a>
  <a href="edit_patient.php">Add Patient</a>
  <a href="edit_appoint.php">Add Appointment</a>
  <a href="edit_nurses.php">Add Nurse</a>
  <a href="edit_staff.php">Add Staff</a>
  <a href="edit_serial.php">Add serial time</a>  
  <a href="edit_blood.php">Add Blood document</a>
  <a href="edit_salary.php">Add Salary document</a>
  <a href="edit_operation.php">Add Operation Info</a>
  <a href="edit_admit.php">Add Admit Info</a>
  <a href="edit_release.php">Add Release Info</a>
  <a href="edit_death.php">Add Death Report</a>
  <a href="edit_birth.php">Add Birth Report</a>
  <a href="blood.php">Blood document</a>
  <a href="salary.php">Salary document</a>
  <a href="operation.php">Operation Info</a>
  <a href="admit.php">Admit Info</a>
  <a href="release.php">Release Info</a>
  <a href="death.php">Death Report</a>
  <a href="birth.php">Birth Report</a>
  <a href="logout.php">log out</a>

</div>
<div id="mySidenav" class="sidenav">
  <a href="doctor.php" id="a1">Doctors</a>
  <a href="patient.php" id="a2">Patients</a>
  <a href="appoint.php" id="a3">Appointment</a>
  <a href="report.php" id="a4">Reports</a>
  <a href="staff.php" id="a5">Staffs</a>
  <a href="nurses.php" id="a6">Nurses</a>
  <a href="serial.php" id="a7">Serial Times</a>
  <a href="profile.html" id="a8">Admin Profile</a>
</div>
<div id="hh">
<h1>Welcome To Hospital management System</h1>
</div>




<script>
document.onmousedown=RightClickDisable;
function RightClickDisable(event){
if(event.button==2){
alert ("Sorry: Your Right Click has been disabled by the administrators");
return false;
}
}
</script>







</body>
</html>
