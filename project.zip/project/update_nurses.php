<?php
require('session.php');
?>
<?php
require('mobilevalid.php');
?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `nurse_name`, `address`, `phone`, `salary` FROM nurse WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['nurse_name'];
	$address=$row['address'];
    $phone=$row['phone'];
	$salary=$row['salary'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
require('edit_nurse.html');
//Update the data 
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['nname'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $salary=$_POST['salary'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE nurse SET `nurse_name`='{$name}', `address`='{$address}', `phone` = '{$phone}', `salary` = '{$salary}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'nurses.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>
