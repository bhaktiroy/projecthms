<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $pname=$_POST['pname'];
    $dname=$_POST['dname'];
    $time=$_POST['time'];
    $date=$_POST['date'];
    $fee=$_POST['fee'];
    $pprblm=$_POST['pprblm'];
    $paddress=$_POST['paddress'];
    $gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `appoint`(`pname`, `dname`, `time`, `date`, `fee`, `pprblm`, `paddress`, `gender`, `visible`) 
             VALUES('{$pname}', '{$dname}', '{$time}', '{$date}', '{$fee}', '{$pprblm}', '{$paddress}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'appoint.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_appoint.html');
 ?>
