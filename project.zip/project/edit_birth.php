<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['name'];
    $fname=$_POST['fname'];
    $mname=$_POST['mname'];
    $address=$_POST['address'];
	$time=$_POST['time'];
	$date=$_POST['date'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `birth_info` (`name`, `fname`, `mname`, `address`, `time`, `date`, `gender`, `visible`)
             VALUES('{$name}', '{$fname}', '{$mname}', '{$address}', '{$time}', '{$date}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'birth.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_birth.html');
 ?>
