<?php
session_start();
include('dbconnect.php');
//admin login
if(isset($_POST['submit'])) {
  $visibility = 1;
  $myusername = mysqli_real_escape_string($connection,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
  $sql = "SELECT `id` FROM login_user WHERE `user`= '{$myusername}' and `password` = '{$mypassword}' AND `visible` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: home.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}

?>

<DOCTYPE html>
  <html>
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  
<style>
  body{
margin;o;
//background:url('img/img1.jpg');
//background-size:cover;
font-family:sans-serif;
}
.center {
    margin: auto;
    width: 50%;
	font-size:30px;
	text-align:center;
}
.a1{
width:350px;
height:350px;
background:	 #f2f2f2;
margin:o auto;
padding-top:10px;
padding-left10px;
border-radius:15px;
color:white;
font-size:bold;
margin-left:40%;
margin-top:150px
}

h2{
color:black;
text-align:center;
}
label a{
color:black;
font-size:15px;
}

.a1 input[type="text"]{
width:200px;
height:35px;
color:black;
font-size:16px;
border:o;
padding-left:5px;
}
.a1 input[type="password"]{
width:200px;
height:35px;
color:black;
font-size:16px;
border:o;
padding-left:5px;
}

::placeholder:{
color:black;
}
.a1 input[type="submit"]{
width:200px;
height:35px;
color:black;
font-size:20px;
background:#87CEEB;
cursor:pointer;
border:0;
box-shadow:inset -4px -4px rgba(0 0 0 .5);
}
.a1 input[type="submit"]:hover
{
background-color:#cce699;
}
.a1 input[type="text"]:hover
{
background-color: #f1f1f1;
}
.a1 input[type="password"]:hover
{
background-color: #f1f1f1;
}

/*footer*/
.footer{
background-color:#f2f2f2;
margin-top:400px;
height:70px;
width:100%;
padding:2px;


}
h2{
text-align:center;
font-size:30px;
}
</style>
</head>
<body>
<div class="center">
  <h1>Hospital Management System</h1>
</div>


<div class="a1">

<h2>Login Here<h2>
<form action="" method="POST">
	
	<input type="text" name="username" placeholder="Enter username..." required><br><br>
	
	<input type="password" name="password" placeholder="Enter password..." required><br><br>
	<input type="submit" name="submit" value="Login"><br/><br/>
	<label><a href="#" >Forget password</a></label>
</form>	
</div>
<div class="footer">
<h2>This software made in Bangladesh<h2>
 </div> 
  
  
  
  
  
  
  
  
  </body>
  </html>


