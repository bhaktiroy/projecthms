<?php
require('session.php');
?>
<?php
require('blood.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM blood WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='voktu'>
    <tr>
    <th>Sl NO</th>
      <th>Blood id</th>
	  <th>Blood group</th>
      <th style='width:200px;'>Donor name</th>
      <th>Patient name</th>
      <th>date</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
	  echo "<td>".$row['bgroup']."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['donrname'])."</td>";
      echo "<td>".$row['pname']."</td>";
      echo "<td>".$row['date']."</td>";
      echo "<td>"."<a href = 'update_blood.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'bldelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
