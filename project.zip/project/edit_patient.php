<?php
require('session.php');
?>
<?php
require('mobilevalid.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $name=$_POST['pname'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `npatient` (`patient_name`, `address`, `phone`, `gender`, `visible`)
             VALUES('{$name}', '{$address}', '{$phone}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'patient.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('new_patient.html');
 ?>
