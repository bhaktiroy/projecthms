<?php
require('session.php');
?>
<?php
require('nurses.html');
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM nurse WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);
    if($result){
      echo "<table id='nurse'>
    <tr>
    <th>Sl NO</th>
      <th>Nurse id</th>
      <th style='width:200px;'>Nurse name</th>
	  <th>Address</th>
      <th>Phone</th>
	  <th>salary</th>
	  <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$id."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['nurse_name'])."</td>";
      echo "<td>".$row['address']."</td>";
	  echo "<td>".$row['phone']."</td>";
      echo "<td>".$row['salary']."</td>";
      echo "<td>"."<a href = 'update_nurses.php?id=$id' id='update'>Edit</a>"."</td>";
      echo "<td>"."<a href = 'nurdelete.php?id=$id' id='delete'>Del</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);

 ?>
