<?php
require('session.php');
?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])) {
    $slamount=$_POST['slamount'];
    $name=$_POST['name'];
    $work=$_POST['work'];
    $position=$_POST['position'];
	$gender=$_POST['gender'];
  if (!mysqli_connect_errno()) {
    $query = "INSERT INTO `salary` (`slamount`, `name`, `work`, `position`, `gender`, `visible`)
             VALUES('{$slamount}', '{$name}', '{$work}', '{$position}', '{$gender}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "Insert Successfull";
      echo "<script>window.location.href = 'salary.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }
  mysqli_close($connection);
}
require('add_salary.html');
 ?>
