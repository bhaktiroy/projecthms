<?php
require ('regggex.php');
include('dbconnect.php');
if (isset($_POST['submit'])) {
  $mobile =$_POST['phone'];
  if (mobile_validation($mobile)==1) {
    $sql="INSERT INTO regex(`phone`) VALUES('{$mobile}')";
    $result = mysqli_query($connection,$sql);
    if ($result) {
      echo "<script>alert('correct mobile number')</script>";
    }
  }else{
    echo "<script>alert('Incorrect mobile number')</script>";
  }
}
mysqli_close($connection);
//require('edit_dr_list.html');
?>

